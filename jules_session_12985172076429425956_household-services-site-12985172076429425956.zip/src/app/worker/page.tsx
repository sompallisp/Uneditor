import React from 'react';

export default function WorkerPortal() {
  const jobs = [
    { id: 101, title: 'Deep Cleaning 3BR House', location: 'Downtown', pay: '$120', date: 'Today, 2:00 PM', status: 'Open' },
    { id: 102, title: 'Fix Leaky Faucet', location: 'Westside', pay: '$50', date: 'Tomorrow, 10:00 AM', status: 'Open' },
    { id: 103, title: 'Mow Front and Back Yard', location: 'North Suburbs', pay: '$60', date: 'Oct 25, 9:00 AM', status: 'Open' },
    { id: 104, title: 'Assemble IKEA Wardrobe', location: 'Eastside', pay: '$80', date: 'Oct 26, 4:00 PM', status: 'Open' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Worker Portal</h1>
        <p className="mt-2 text-lg text-gray-600">Find jobs, manage your schedule, and track earnings.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div className="bg-white shadow sm:rounded-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Available Jobs</h2>
          <div className="space-y-4">
            {jobs.map((job) => (
              <div key={job.id} className="border border-gray-200 rounded-md p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                <div>
                  <h3 className="text-lg font-medium text-blue-600">{job.title}</h3>
                  <p className="text-sm text-gray-500">{job.location} • {job.date}</p>
                  <p className="text-md font-semibold text-green-600 mt-1">{job.pay}</p>
                </div>
                <button
                  type="button"
                  className="mt-4 sm:mt-0 inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Accept Job
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white shadow sm:rounded-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Become a Worker</h2>
          <p className="text-sm text-gray-600 mb-4">Join our platform to start earning money on your own schedule.</p>
          <form className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">First name</label>
                <input type="text" name="first-name" id="first-name" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" />
              </div>
              <div>
                <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">Last name</label>
                <input type="text" name="last-name" id="last-name" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" />
              </div>
            </div>
            <div>
              <label htmlFor="skills" className="block text-sm font-medium text-gray-700">Skills / Services Offered</label>
              <input type="text" name="skills" id="skills" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" placeholder="E.g., Cleaning, Plumbing" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email address</label>
              <input type="email" name="email" id="email" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" />
            </div>
            <button type="button" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
              Apply Now
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
