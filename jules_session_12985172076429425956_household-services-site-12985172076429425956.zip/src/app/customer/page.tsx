import React from 'react';

export default function CustomerPortal() {
  const services = [
    { id: 1, name: 'House Cleaning', description: 'Deep cleaning, regular cleaning, move-in/move-out.', icon: '🧹' },
    { id: 2, name: 'Plumbing', description: 'Fix leaks, install fixtures, unclog drains.', icon: '🪠' },
    { id: 3, name: 'Electrical', description: 'Lighting installation, electrical repairs, rewiring.', icon: '⚡' },
    { id: 4, name: 'Lawn Care', description: 'Mowing, trimming, landscaping, leaf removal.', icon: '🌱' },
    { id: 5, name: 'Handyman', description: 'Furniture assembly, picture hanging, minor repairs.', icon: '🛠️' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Customer Portal</h1>
        <p className="mt-2 text-lg text-gray-600">Find and book trusted professionals for your household needs.</p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((service) => (
          <div key={service.id} className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <span className="text-4xl mr-4">{service.icon}</span>
                <h3 className="text-lg leading-6 font-medium text-gray-900">{service.name}</h3>
              </div>
              <div className="mt-4 text-sm text-gray-500">
                {service.description}
              </div>
              <div className="mt-5">
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Book Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white shadow sm:rounded-lg mt-8 p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Request a Custom Service</h2>
        <form className="space-y-4">
          <div>
            <label htmlFor="service-type" className="block text-sm font-medium text-gray-700">Service Type</label>
            <input type="text" name="service-type" id="service-type" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" placeholder="E.g., Window Washing" />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description of work needed</label>
            <textarea id="description" name="description" rows={3} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder="Please provide details..."></textarea>
          </div>
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-gray-700">Preferred Date</label>
            <input type="date" name="date" id="date" className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm border p-2" />
          </div>
          <button type="button" className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
            Submit Request
          </button>
        </form>
      </div>
    </div>
  );
}
