import React from 'react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center space-y-12 py-12">
      
      <div className="text-center max-w-3xl">
        <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
          <span className="block">Your one-stop shop for</span>
          <span className="block text-blue-600">Household Services</span>
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Whether you need a quick repair, a deep clean, or want to offer your skills to others, HomeServices connects you with exactly what you need at unbeatable prices.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl">
        
        <div className="bg-white rounded-lg shadow-lg p-8 text-center flex flex-col items-center hover:shadow-xl transition-shadow">
          <div className="bg-blue-100 rounded-full p-4 mb-4">
            <span className="text-3xl">🏠</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">For Customers</h2>
          <p className="text-gray-600 mb-6 flex-grow">
            Find vetted professionals for cleaning, plumbing, yard work, and more.
          </p>
          <Link href="/customer" className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
            Find a Service
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 text-center flex flex-col items-center hover:shadow-xl transition-shadow">
          <div className="bg-green-100 rounded-full p-4 mb-4">
            <span className="text-3xl">🛠️</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">For Workers</h2>
          <p className="text-gray-600 mb-6 flex-grow">
            Be your own boss. Find local jobs, set your schedule, and get paid fast.
          </p>
          <Link href="/worker" className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700">
            Find Work
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 text-center flex flex-col items-center hover:shadow-xl transition-shadow">
          <div className="bg-purple-100 rounded-full p-4 mb-4">
            <span className="text-3xl">💰</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Compare Prices</h2>
          <p className="text-gray-600 mb-6 flex-grow">
            See how our transparent pricing beats the leading competitors.
          </p>
          <Link href="/pricing" className="w-full inline-flex justify-center items-center px-4 py-2 border border-purple-600 text-base font-medium rounded-md shadow-sm text-purple-600 bg-white hover:bg-purple-50">
            View Prices
          </Link>
        </div>

      </div>
    </div>
  );
}
