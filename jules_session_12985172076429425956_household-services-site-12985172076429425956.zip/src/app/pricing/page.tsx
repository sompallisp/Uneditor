import React from 'react';

export default function PricingComparison() {
  const comparisons = [
    { service: 'Standard House Cleaning (3BR)', ourPrice: '$100', competitorA: '$130', competitorB: '$150' },
    { service: 'Basic Plumbing Repair', ourPrice: '$65/hr', competitorA: '$85/hr', competitorB: '$95/hr' },
    { service: 'Lawn Mowing', ourPrice: '$45', competitorA: '$60', competitorB: '$75' },
    { service: 'Furniture Assembly', ourPrice: '$55/hr', competitorA: '$70/hr', competitorB: '$80/hr' },
    { service: 'Electrical Inspection', ourPrice: '$90', competitorA: '$120', competitorB: '$140' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Price Comparison</h1>
        <p className="mt-2 text-lg text-gray-600">See how our prices stack up against the competition.</p>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Average Rates for Common Services</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">Based on national averages for similar service apps.</p>
        </div>
        <div className="border-t border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-green-600 uppercase tracking-wider font-bold">
                    HomeServices (Us)
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    TaskMaster (Competitor)
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ThumbPro (Competitor)
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {comparisons.map((row, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {row.service}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-green-600">
                      {row.ourPrice}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {row.competitorA}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {row.competitorB}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <p className="text-sm text-blue-700">
              <strong>Why are we cheaper?</strong> We take a smaller commission from our workers, meaning they get paid more and you pay less. It&apos;s a win-win!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
